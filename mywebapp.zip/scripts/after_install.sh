#!/bin/bash
set -e
chown -R nginx:nginx /usr/share/nginx/html
