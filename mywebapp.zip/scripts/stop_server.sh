#!/bin/bash
set -e
systemctl stop nginx || true
