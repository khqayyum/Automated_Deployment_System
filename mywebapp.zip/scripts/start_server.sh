#!/bin/bash
set -e
systemctl start nginx
